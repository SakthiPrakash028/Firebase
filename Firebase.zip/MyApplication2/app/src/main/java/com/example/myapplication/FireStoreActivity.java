package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
public class FireStoreActivity extends AppCompatActivity {
    private EditText nameEditText, emailEditText;
    private Button submitButton, updateButton, deleteButton;
    private ListView contactListView;
    private FirebaseFirestore db;
    private ArrayAdapter<String> adapter;
    private ArrayList<String> contactList;
    private ArrayList<String> contactIds; // Store IDs of contacts
    private String selectedContactId = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fire_store);

        db = FirebaseFirestore.getInstance();
        nameEditText = findViewById(R.id.name);
        emailEditText = findViewById(R.id.email);
        submitButton = findViewById(R.id.submitButton);
        updateButton = findViewById(R.id.updateButton);
        deleteButton = findViewById(R.id.deleteButton);
        contactListView = findViewById(R.id.list_view);

        contactList = new ArrayList<>();
        contactIds = new ArrayList<>(); // Initialize contactIds array
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, contactList);
        contactListView.setAdapter(adapter);

        displayContacts();

        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = nameEditText.getText().toString().trim();
                String email = emailEditText.getText().toString().trim();

                if (!name.isEmpty() && !email.isEmpty()) {
                    addContact(name, email);
                } else {
                    Toast.makeText(FireStoreActivity.this, "Please enter name and email", Toast.LENGTH_SHORT).show();
                }
            }
        });

        updateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = nameEditText.getText().toString().trim();
                String email = emailEditText.getText().toString().trim();

                if (selectedContactId != null && !name.isEmpty() && !email.isEmpty()) {
                    int position = contactIds.indexOf(selectedContactId);
                    if (position != -1) {
                        updateContact(selectedContactId, name, email, position); // Pass position to updateContact
                    }
                } else {
                    Toast.makeText(FireStoreActivity.this, "Please select a contact and enter name and email", Toast.LENGTH_SHORT).show();
                }
            }
        });

        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (selectedContactId != null) {
                    int position = contactIds.indexOf(selectedContactId);
                    if (position != -1) {
                        deleteContact(selectedContactId, position); // Pass position to deleteContact
                    }
                } else {
                    Toast.makeText(FireStoreActivity.this, "Please select a contact to delete", Toast.LENGTH_SHORT).show();
                }
            }
        });

        contactListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String contactInfo = adapter.getItem(position);
                if (contactInfo != null) {
                    String[] parts = contactInfo.split(" - ");
                    if (parts.length == 3) { // Assuming ID is the third part
                        nameEditText.setText(parts[0]);
                        emailEditText.setText(parts[1]);
                        selectedContactId = contactIds.get(position); // Get the ID from contactIds
                    }
                }
            }
        });
    }

    private void addContact(String name, String email) {
        Map<String, Object> contact = new HashMap<>();
        contact.put("name", name);
        contact.put("email", email);

        db.collection("contacts")
                .add(contact)
                .addOnCompleteListener(new OnCompleteListener<DocumentReference>() {
                    @Override
                    public void onComplete(@NonNull Task<DocumentReference> task) {
                        if (task.isSuccessful()) {
                            Toast.makeText(FireStoreActivity.this, "Contact added successfully", Toast.LENGTH_SHORT).show();
                            displayContacts();
                            nameEditText.setText("");
                            emailEditText.setText("");
                        } else {
                            Toast.makeText(FireStoreActivity.this, "Error adding contact", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }

    private void updateContact(String id, String name, String email, int position) {
        db.collection("contacts").document(id)
                .update("name", name, "email", email)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            Toast.makeText(FireStoreActivity.this, "Contact updated successfully", Toast.LENGTH_SHORT).show();
                            displayContacts();
                            nameEditText.setText("");
                            emailEditText.setText("");
                            selectedContactId = null;
                        } else {
                            Toast.makeText(FireStoreActivity.this, "Error updating contact", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }

    private void deleteContact(String id, int position) {
        db.collection("contacts").document(id)
                .delete()
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            Toast.makeText(FireStoreActivity.this, "Contact deleted successfully", Toast.LENGTH_SHORT).show();
                            displayContacts();
                            nameEditText.setText("");
                            emailEditText.setText("");
                            selectedContactId = null;
                        } else {
                            Toast.makeText(FireStoreActivity.this, "Error deleting contact", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }

    private void displayContacts() {
        contactList.clear();
        contactIds.clear(); // Clear contactIds before populating it
        db.collection("contacts")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (DocumentSnapshot document : task.getResult()) {
                                String id = document.getId(); // Get the document ID
                                String name = document.getString("name");
                                String email = document.getString("email");
                                contactList.add(name + " - " + email + " - " + id); // Add ID to the contact info
                                contactIds.add(id); // Add ID to contactIds
                            }
                            adapter.notifyDataSetChanged();
                        } else {
                            Toast.makeText(FireStoreActivity.this, "Error getting contacts", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }
}